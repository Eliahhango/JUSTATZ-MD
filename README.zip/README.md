## 𝘑𝘜𝘚𝘛𝘈𝘛𝘡 MD
 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?font=Time+New+Roman&color=red&size=25&center=true&vCenter=true&width=600&height=100&lines=I'm+𝘑𝘜𝘚𝘛𝘈𝘛𝘡+md+Created+by+𝘓𝘜𝘊𝘒𝘔𝘈𝘕.&heart;++;Self-taught+Back-Created+By,;𝘑𝘜𝘚𝘛𝘈𝘛𝘡+𝘛𝘡+Am+The,;Best+Is+Bot+For+You+To,;Deploy..<3"></a>
 <a href="https://telegra.ph/file/a426523c1f8b7ee7430f1.jpg">
 <img alt="𝘑𝘜𝘚𝘛𝘈𝘛𝘡-MD" height="300" src="https://telegra.ph/file/a426523c1f8b7ee7430f1.jpg">

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
</h1> 
<p align="center">l introduce <b>𝘑𝘜𝘚𝘛𝘈𝘛𝘡-MD</b>, a powerful simple WhatsApp bot </p>

</p>
  <p align="center">
<a href="https://github.com/JustaTz01/JUSTATZ-MD?tab=readme-ov-file
?tab=followers"><img title="Followers" src="https://github.com/JustaTz01/JUSTATZ-MD?tab=readme-ov-file
?label=Followers&style=social"></a>
<a href="https://github.com/JustaTz01/JUSTATZ-MD?tab=readme-ov-file/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/𝘫𝘶𝘴𝘵𝘢𝘵𝘻01/𝘫𝘶𝘴𝘵𝘢𝘵𝘻-md?&style=social"></a>
<a href="https://github.com/JustaTz01/JUSTATZ-MD?tab=readme-ov-file/network/members"><img title="Forks" src="https://img.shields.io/github/forks/JustaTz01/JUSTATZ-md?style=social"></a>
<a href="https://github.com/JustaTz01/𝘑𝘶𝘴𝘵𝘢𝘛𝘻-md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/JustaTz01/𝘑𝘶𝘴𝘵𝘢𝘛𝘻-md?label=Watching&style=social"></a>

</p>
<p align="center"><img src="https://profile-counter.glitch.me/{JustaTz01}/count.svg" alt="𝘑𝘶𝘴𝘵𝘢𝘛𝘻-md :: Visitor's Count"/></p>

---


</a>
  <div align="center">
  <img src="https://spogit.vercel.app/api?theme=dark&black=true&scan=true" alt="Widget with the current Spotify song"  />
</div>

---

<p align="cente𝘳  <a href="https://github.com/JustaTz01/𝘑𝘶𝘴𝘵𝘢𝘛𝘻-md"><b>𝘑𝘶𝘴𝘵𝘢𝘛𝘻-md</b></a> Support Deploy On...
</p>

<p align="center">
  <a href="https://github.com/boniphace478/JustaTz01-Md/blob/main/temp/deploy-on-vps.md"><img src="https://img.shields.io/badge/self hosting-3d1513?style=for-the-badge&logo=serverless&logoColor=FD5750"></a>
  <a href="https://dashboard.heroku.com/new?template=https://github.com/JustaTz01/𝘑𝘶𝘴𝘵𝘢𝘛𝘻-Md/tree/main"><img src="https://img.shields.io/badge/heroku-9d7acc?style=for-the-badge&logo=heroku&logoColor=430098"></a>
  <a href="https://youtu.be/izoxfW3anrU"><img src="https://img.shields.io/badge/CodeSpace-green?colorA=%23ff000&colorB=%23017e40&style=for-the-badge&logo=git&logoColor=white"></a>
</p>



    
 
 



---





## HOW TO DEPLOY 𝘑𝘜𝘚𝘛𝘈𝘛𝘡 MD


## 1.FIRST STEP 
## Fork 𝘑𝘶𝘴𝘵𝘢𝘛𝘻 Md Repo
👇 👇  👇 👇
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+ℙ𝕃𝔼𝔸𝕊𝔼+𝔽𝕆ℝ𝕂+𝕋ℍ𝔼+ℝ𝔼ℙ𝕆)](https://git.io/typing-svg)
 
- <a href="https://github.com/JustaTz01/𝘑𝘜𝘚𝘛𝘈𝘛𝘡-MD/fork"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/FORK THIS REPO-h?color=darkblue&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

star✨ my repo if you like this bot🤖


## 2.SECOND STEP 


 GET SESSION ID BY

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+𝕋ℍ𝕀𝕊+𝕀𝕊+𝕊𝔼𝕊𝕊𝕀𝕆ℕ+𝕊𝔼𝕋𝔼😎)](https://git.io/typing-svg)

### QR SITE

- <a href="https://Justa-Tz.onrender.com/wasiqr"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/QR CODE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

### SESSION SITE

- <a href="https://Justa-Tz.onrender.com"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/PAIRING CODE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>





### 3.THIRD STEP 
1. If You Don't Have An Account On Heroku**

   <br>
    <a 
- <a align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-darkblue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

### 2. If You Have Account On Heroku**👇 👇 👇

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=■+■+■+■+■+100%+𝗦𝗔𝗙𝗘+𝗢𝗡+𝗛𝗘𝗥𝗢𝗞𝗨)](https://git.io/typing-svg)
 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

   <br>
    - <a href='https://dashboard.heroku.com/new?template=https://github.com/JustaTz01/𝘑𝘜𝘚𝘛𝘈𝘛𝘡-MD' target="_darkblue"><img alt='DEPLOY TO HEROKU' src="https://img.shields.io/badge/Deploy%20To%20Heroku-darkblue?style=for-the-badge&logo=heroku" width="200" height="38.45"/></a></p>


### DEPLOY ON RENDER

1. If you don't have an account in RENDER, create one and deploy.
    <br>
    <a href='https://dashboard.render.com/select-repo?type=web' target="_darkblue"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/></a>


   ###

CONTACT DEVELOPER ON WHATSAPP 

<a href="https://wa.link/4d9cpj" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/𝘫𝘶𝘴𝘵𝘢𝘵𝘻 tech contact -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


  
 
<a href="https://youtube.com/@justatz?si=goWny5eXB2g5qKfw" target="_blank">
    <img alt="𝘞𝘩𝘢𝘵'𝘴𝘢𝘱𝘱 𝘨𝘳𝘰𝘶𝘱" src="https://img.shields.io/badge/ 𝘑𝘜𝘚𝘛𝘈𝘛𝘡_TECH  CHANNEL -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
 

## License

The WhatsApp Bot 𝘑𝘜𝘚𝘛𝘈𝘛𝘡-MD is released under the [MIT License](https://opensource.org/licenses/MIT).
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

🌟 THANK YOU FOR CHOOSING 𝘑𝘜𝘚𝘛𝘈𝘛𝘡-MD 🌟
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## DEVELOPERS :

- [**𝘑𝘜𝘚𝘛𝘈𝘛𝘡 TECH**](https://github.com/JustaTz01)
- [**Developers YT**](https://youtube.com/@justatz?si=goWny5eXB2g5qKfw)
 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
 
★EVERYTHING IS POSSIPLE💥. ©
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

     

